// Bader Daka 208219212
// Adham Jaber 204218184
#pragma once
#include <iostream>
#include <memory>
#include <string>
#include <map>
using namespace std;

template <class K, class V>
class ChacheMemory
{

public:
    void add(const K &key, const V &value)
    {

        if (sv.find(key) == sv.end())
        {
            sv[key] = shared_ptr<V>(new V(value));
        }
        else
        {
            throw("DuplicateKeyException");
        }
    }
    void erase(const K &key)
    {

        if (sv.find(key) == sv.end())
        {
            throw("ObjectNotExistException");
        }
        else
        {
            sv.erase(key);
        }
    }
    shared_ptr<V> get(const K &key)
    {

        if (wv.find(key) != wv.end())
        {
            if (wv[key].expired() == true)
            {
                wv.erase(key);
            }
            else
            {
                return wv[key].lock();
            }
        }
        else
        {
            if (sv.find(key) == sv.end())
            {
                return nullptr;
            }
            else
            {
                wv[key] = weak_ptr<V>(sv[key]);
                return wv[key].lock();
                // return sv[key];
            }
        }
        return nullptr;
    }
    void print(K key)
    {
        cout << *sv[key] << endl;
    }

    auto getmapbegin() const
    {
        return sv.begin();
    }
     auto getmapend() const
    {
        return sv.end();
        
    }
    void erasebyid(K id)
    {
        sv.erase(id);

    }

private:
    map<K, shared_ptr<V>> sv;
    map<K, weak_ptr<V>> wv;
};