// Bader Daka 208219212
// Adham Jaber 204218184
#pragma once
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

class employee
{
public:
    employee(string s = "\0", int salary = 0, int seniority = 0) : m_id(s), m_salary(salary), m_seniority(seniority) {}
    void load(istream &in);
    void save(ostream &out);
 string getid() const
    {

        return m_id;
    }
    friend ostream &operator<<(ostream &out, const employee &e);

private:
    string m_id;
    int m_salary;
    int m_seniority;
};

