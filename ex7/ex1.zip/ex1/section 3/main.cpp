// Bader Daka 208219212
// Adham Jaber 204218184
#include "../section 2/chache.h"
#include "employee.h"
#include <fstream>
#include<cstring>
using namespace std;

int main(int argc, char const *argv[])
{
    ChacheMemory<string, employee> c1;
    int counter=0;
 
    ofstream outfile;
    outfile.open("../section 2/emps.bin", ios::binary | ios::out);
    c1.add("bader", employee("bader", 5000, 40));
    c1.add("noor", employee("noor", 8000, 50));
    // c1.add(4, employee("noor", 8000, 30));
       
    
    for(auto it=c1.getmapbegin(); it!=c1.getmapend();it++)
    {
        
        (*it->second).save(outfile);
        counter++;
    }
    cout << counter << endl;
    // outfile<<EOF;
    outfile.close();

    ifstream infile;
    infile.open("../section 2/emps.bin", ios::binary | ios::in);
    employee e;
    counter=0;
  
 
    while (!infile.eof())
    {

        e.load(infile);
        // cout<<e<<endl;
        c1.erasebyid(e.getid());
        c1.add(e.getid(),e);
        counter++;
    }
    
    cout<<counter<<endl;
    for(auto it=c1.getmapbegin(); it!=c1.getmapend();it++)
    {
        
        cout<< (*it->second)<<endl;
    
    }

    cout<< (*c1.get("bader"))<<endl;
    // c1.print("noor");


    infile.close();
    return 0;
}
