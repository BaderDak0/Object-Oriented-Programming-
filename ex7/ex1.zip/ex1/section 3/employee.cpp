// Bader Daka 208219212
// Adham Jaber 204218184
#include "employee.h"

void employee::save(ostream &out)
{
    int size = m_id.length();
    out.write((char *)&size, sizeof(int));
    out.write(m_id.c_str(), size);
    out.write((char *)&m_salary, sizeof(int));
    out.write((char *)&m_seniority, sizeof(int));
}
void employee::load(istream &in)
{
 
    char *id;
    int size = 0;
    in.read((char *)&size, sizeof(int));
    id = new char[size+1];
    in.read(id, size);
    id[size]=0;
    m_id = id;
    delete[] id; // dont forget to delete dynamically allocated memory
    in.read((char *)&m_salary, sizeof(int));
    in.read((char *)&m_seniority, sizeof(int));
  
}
ostream &operator<<(ostream &out, const employee &e)
{

    out << e.m_id << " " << e.m_salary << " " << e.m_seniority << endl;

    return out;
}