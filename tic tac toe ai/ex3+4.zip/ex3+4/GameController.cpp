// Name:Bader Daka id:208219212
// Name:Adam Jaber id:204218184
#include "GameController.h"
#include <iostream>

void GameController::play()
{

  
   cout << "Game Name:" << m_game->getGamename() << endl;
   Position pos;
   string win = "Win";
   string lose = "Lose";
   string draw = "Draw";
   string Result = "";
   int x=0;
   m_game->first_show_board();
   while (1)
   {

      cout << "please enter a move location: ";
      cin >> x;
      m_game->setplayerpos(x);
      Result = m_game->GameResult();
      if (Result == win || Result == lose || Result == draw)
      {
         cout << "---------------------------------" << endl;

         m_user->showboard(m_game);
         break;
      }
      cout << "---------------------------------" << endl;

      m_user->showboard(m_game);
      m_game->AI_Play();
       Result = m_game->GameResult();
      if (Result == win || Result == lose || Result == draw)
      {
         cout << "---------------------------------" << endl;
         m_user->showboard(m_game);
         break;
      }
      cout << "---------------------------------" << endl;
      m_user->showboard(m_game);
   }
}