// Name:Bader Daka id:208219212
// Name:Adam Jaber id:204218184
#pragma once
#include <string>
using namespace std;



struct Position
{
    int x;
    int y;
};



class Player_user
{
public:
    Player_user(string name ,int Rank);
    string getname() const;
    int getrank() const;
    Position getpos() const;
    void setname(string name);
    void setrank(int Rank);
    void setpos(Position pos);

private:
    string m_name;
    int m_Rank;
    Position m_Position;
};


