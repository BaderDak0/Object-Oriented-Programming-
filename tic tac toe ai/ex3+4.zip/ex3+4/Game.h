// Name:Bader Daka id:208219212
// Name:Adam Jaber id:204218184
#pragma once
#include "PlayersClases.h"

#include <string>
using namespace std;

class Gamee
{
public:
    
    Gamee(string gameName, string name, int Rank, string nameAI, string dificulty, int row, int col)
        : m_Gamename(gameName), m_dificulty(dificulty), m_row(row), m_col(col), m_nameAI(nameAI)
    {

        m_player = new Player_user(name, Rank);

        m_board = new int *[row];
        for (int i = 0; i < col; i++)
        {
            m_board[i] = new int[row];
        }
        for (int i = 0; i < m_row; i++)
            for (int j = 0; j < m_col; j++)
            {
                m_board[i][j] = 0;
            }
    }
    ~Gamee()
    {

        delete m_player;

        for (int i = 0; i < m_row; ++i)
        {
            delete[] m_board[i];
        }
        delete[] m_board;
    }

    virtual void setplayerpos(int) = 0;
    // virtual Position get_Playerposition() const = 0;
    virtual string getdificulty() = 0;
    virtual string getGamename() = 0;
    virtual void show_board() = 0;
    virtual void first_show_board() = 0;
    virtual void AI_Play() = 0;
    virtual string GameResult() = 0;

protected:
    string m_nameAI;
    string m_Gamename;
    Player_user *m_player;
    string m_dificulty;
    int m_row;
    int m_col;
    int **m_board;
};
