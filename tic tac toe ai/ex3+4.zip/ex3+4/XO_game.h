// Name:Bader Daka id:208219212
// Name:Adam Jaber id:204218184
#pragma once

#include "Game.h"
#include <cstring>
class XO : public Gamee
{

public:
    XO(string gamename, string name, int Rank, string nameAI, string dificulty,int row,int col);
    ~XO(){}
    virtual void setplayerpos(int);
    // virtual Position get_Playerposition() const {};
    virtual string GameResult();
    virtual string getdificulty();
    virtual string getGamename();
    virtual void AI_Play()=0;
    virtual void show_board();
    virtual void first_show_board();
    int sumRow( int row);
    int sumCol( int col);
    int sumDiag();
    int sumDiag2();
};