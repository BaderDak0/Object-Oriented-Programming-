// Name:Bader Daka id:208219212
// Name:Adam Jaber id:204218184
#include "XO_game.h"
#include <iostream>
using namespace std;

XO::XO(string gamename, string name, int Rank, string nameAI, string dificulty,int row,int col)
    : Gamee(gamename, name, Rank, nameAI, dificulty, row, col)
{
}

void XO::setplayerpos(int x)
{
   
    Position pos;
    while (1)
    {
        while (1)
        {
            if (x > 9 || x < 0)
            {
                cout << "invalid move!! please Try Again!" << endl;
                cin >> x;
            }
            else
                break;
        }

        switch (x)
        {
        case 1:
            pos.x = 0;
            pos.y = 0;
            break;
        case 2:
            pos.x = 0;
            pos.y = 1;
            break;
        case 3:
            pos.x = 0;
            pos.y = 2;
            break;
        case 4:
            pos.x = 1;
            pos.y = 0;
            break;
        case 5:
            pos.x = 1;
            pos.y = 1;
            break;
        case 6:
            pos.x = 1;
            pos.y = 2;
            break;
        case 7:
            pos.x = 2;
            pos.y = 0;
            break;
        case 8:
            pos.x = 2;
            pos.y = 1;
            break;
        case 9:
            pos.x = 2;
            pos.y = 2;
            break;
        }

        if (m_board[pos.x][pos.y] == 0)
        {
            m_board[pos.x][pos.y] = 1;
            return;
        }
        else
        {

            cout << "you pick invalid location please try again" << endl;
            cin >> x;
        }
    }
}



string XO::getdificulty() { return m_dificulty; }
string XO::getGamename() { return m_Gamename; }
void XO::show_board()
{

    for (int i = 0; i < m_row; i++)
    {
        for (int j = 0; j < m_col; j++)
        {
            if (m_board[i][j] == 1)
                cout << "X"
                     << "|";
            else if (m_board[i][j] == 2)
                cout << "O"
                     << "|";
            else if (m_board[i][j] == 0)
                cout << " "
                     << "|";
        }
        cout << endl;
    }
}
void XO::first_show_board()
{

    int counter=1;
    for (int i = 0; i < m_row; i++)
    {
        for (int j = 0; j < m_col; j++)
        {
           
                cout << counter
                     << "|";
           counter++;
        }
        cout << endl;
        
    }
    cout<< "this is the board, input shown number to play"<<endl;
}
int XO::sumRow(int row)
{
    int sum = 0;

    for (int j = 0; j < 3; j++)
    {
        if (m_board[row][j] == 0)
            return -1;
        sum += m_board[row][j];
    }
    return sum;
}
int XO::sumCol(int col)
{
    int sum = 0;
    for (int i = 0; i < 3; i++)
    {
        if (m_board[i][col] == 0)
            return -1;
        sum += m_board[i][col];
    }
    return sum;
}
int XO::sumDiag()
{
    int sum = 0;
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (i == j)
            {
                if (m_board[i][j] == 0)
                    return -1;
                sum += m_board[i][j];
            }
        }
    }
    return sum;
}
int XO::sumDiag2()
{
    int sum = 0;
    for (int i = 0, j = 2; i < 3; i++, j--)
    {
        if (m_board[i][j] == 0)
            return -1;
        sum += m_board[i][j];
    }

    return sum;
}

string XO::GameResult()
{
    if (sumRow(0) == 3 || sumRow(1) == 3 || sumRow(2) == 3 || sumCol(0) == 3 || sumCol(1) == 3 || sumCol(2) == 3 || sumDiag() == 3 || sumDiag2() == 3)
    {
         cout << "---------------------------------" << endl;
        cout  <<"<<"   << m_player->getname() << " has won" << ">>" <<endl;
            
        return "Win";
    }
    else if (sumRow(0) == 6 || sumRow(1) == 6 || sumRow(2) == 6 || sumCol(0) == 6 || sumCol(1) == 6 || sumCol(2) == 6 || sumDiag() == 6 || sumDiag2() == 6)
    {
           cout << "---------------------------------" << endl;
        cout  <<"<<"   << m_nameAI << " has won" << ">>" <<  endl;
            
        return "Lose";
    }
    else
    {
        int flag = 0;
        for (int i = 0; i < m_row; i++)
            for (int j = 0; j < m_col; j++)
            {
                if (m_board[i][j] == 0)
                {
                    flag = 1;
                }
            }
        if (flag == 0)
        {
                cout << "---------------------------------" << endl;
            cout <<"<<"  << "Draw" << ">>" <<  endl;
             
            return "Draw";
        }
    }

    return "OK";
}