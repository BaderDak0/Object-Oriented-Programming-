// Name:Bader Daka id:208219212
// Name:Adam Jaber id:204218184
#pragma once

#include "Game.h"
class Userinterface
{

public:
   
    virtual void showboard(Gamee *game) = 0;


  
};

class console_board : public Userinterface
{

public:
   
    virtual void showboard(Gamee *game){game->show_board();}
   

};

class graphic_board : public Userinterface
{

public:

    virtual void showboard(Gamee *game);
    
};