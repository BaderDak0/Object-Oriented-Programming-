// Name:Bader Daka id:208219212
// Name:Adam Jaber id:204218184
#include "PlayersClases.h"

Player_user::Player_user(string name, int Rank) : m_name(name), m_Rank(Rank) {}
string Player_user::getname() const { return m_name; }

int Player_user::getrank() const { return m_Rank; }
Position Player_user::getpos() const { return m_Position; }

void Player_user::setname(string name) { m_name = name; }
void Player_user::setrank(int Rank) { m_Rank = Rank; }
void Player_user::setpos(Position pos) { m_Position = pos; }

///////////////////////////////////////////////
//PlayerAI//

//   Player_AI:: Player_AI( string nameAI,string dificulty):m_nameAI(nameAI),m_dificulty(dificulty){}
//   Position Player_AI:: getpos() const {return m_Position;}
//   void Player_AI:: setpos( Position pos)  {m_Position=pos;}