// Name:Bader Daka id:208219212
// Name:Adam Jaber id:204218184
#pragma once
#include "Userinterface.h"
#include "Game.h"
class GameController
{
public:
   GameController(Gamee* game , Userinterface *user) : m_game(game),m_user(user){}
   void play();


   private:

   Gamee* m_game;
   Userinterface * m_user;
};
