// Name:Bader Daka id:208219212
// Name:Adam Jaber id:204218184
#pragma once 
#include "XO_game.h"



class xo_EDU : public XO {


public: 
 xo_EDU(string gamename, string name, int Rank, string nameAI, string dificulty); 
  virtual void AI_Play();



};


class xo_RAN : public XO {


public:
xo_RAN(string gamename, string name, int Rank, string nameAI, string dificulty); 
    virtual void AI_Play();


};