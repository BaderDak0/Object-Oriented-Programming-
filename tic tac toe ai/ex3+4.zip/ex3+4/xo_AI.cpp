// Name:Bader Daka id:208219212
// Name:Adam Jaber id:204218184
#include "xo_AI.h"
#define Row 3
#define Col 3
xo_EDU::xo_EDU(string gamename, string name, int Rank, string nameAI, string dificulty)
    : XO(gamename, name, Rank, nameAI, dificulty, Row, Col)
{
}
xo_RAN::xo_RAN(string gamename, string name, int Rank, string nameAI, string dificulty)
    : XO(gamename, name, Rank, nameAI, dificulty, Row, Col)
{
}

void xo_EDU::AI_Play()
{
    if (m_board[1][1] == 0)
    {
        m_board[1][1] = 2;
        return;
    }
    // this code make a move by a blocking a player if there two X that could lead to a win in ROW COL DIAG
    for (int i = 0; i < m_row; i++)
        for (int j = 0; j < m_col; j++)
        {
            if (i + 1 < m_row && i + 2 < m_row && m_board[i][j] == 1 && m_board[i + 1][j] == 1 && m_board[i + 2][j] == 0)
            {
                m_board[i + 2][j] = 2;
                return;
            }
            else if (j + 1 < m_col && j + 2 < m_row && m_board[i][j + 1] == 1 && m_board[i][j] == 1 && m_board[i][j + 2] == 0)
            {
                m_board[i][j + 2] = 2;
                return;
            }
            else if (j + 1 < m_col && i + 1 < m_row && j + 2 < m_col && i + 2 < m_row && m_board[i + 1][j + 1] == 1 && m_board[i][j] == 1 && m_board[i + 2][j + 2] == 0)
            {
                m_board[i + 2][j + 2] = 2;
                return;
            }
            else if (i >= 0 && i - 2 >= 0 && m_board[i - 1][j] == 1 && m_board[i][j] == 1 && m_board[i - 2][j] == 0)
            {
                m_board[i - 2][j] = 2;
                return;
            }
            else if (j >= 0 && j - 2 >= 0 && m_board[i][j - 1] == 1 && m_board[i][j] == 1 && m_board[i][j - 2] == 0)
            {
                m_board[i][j - 2] = 2;
                return;
            }
            else if(m_board[0][2]==1&&m_board[2][0]==1&&m_board[1][1]==0)
            {
                m_board[1][1]=2;
                return;
            }
              else if(m_board[0][2]==1&&m_board[1][1]==1&&m_board[2][0]==0)
            {
                m_board[2][0]=2;
                return;
            }
                else if(m_board[0][2]==0&&m_board[1][1]==1&&m_board[2][0]==1)
            {
                m_board[0][2]=2;
                return;
            }
               else if(m_board[0][0]==1&&m_board[2][2]==1&&m_board[1][1]==0)
            {
                m_board[1][1]=2;
                return;
            }
              else if(m_board[0][0]==1&&m_board[1][1]==1&&m_board[2][2]==0)
            {
                m_board[2][2]=2;
                return;
            }
                else if(m_board[2][2]==1&&m_board[1][1]==1&&m_board[0][0]==0)
            {
                m_board[0][0]=2;
                return;
            }


        }
    for (int i = 0; i < m_row; i++)
        for (int j = 0; j < m_col; j++)
        {
            if (m_board[i][j] == 0)
            {
                m_board[i][j] = 2;
                return;
            }
        }
}

void xo_RAN::AI_Play()
{
    for (int i = 0; i < m_row; i++)
        for (int j = 0; j < m_col; j++)
        {
            if (m_board[i][j] == 0)
            {
                m_board[i][j] = 2;
                return;
            }
        }
}
