// Name:Bader Daka id:208219212
// Name:Adam Jaber id:204218184
#include "GameController.h"
#include "xo_AI.h"
#include "PlayersClases.h"
#include <iostream>
using namespace std;

int main(int argc, char const *argv[])
{
    string name;
    string nameP;
    string nameCAI = "XO_AI";
    int GameNum = 0;
    int GameDif = 0;
    int interC = 0;
    cout << "which userinterface you want:" << endl;
    while (1)
    {
        cout << "1 -Console interface" << endl;
        cout << "2 -Graphical interface" << endl;

        cin >> interC;
        if (interC == 1)
            break;
        else
            cout << "sorry we do not support this interface yet please choose again" << endl;
    }
    cout << "which game do you want to play :" << endl;
    while (1)
    {
        cout << "1 - tic tac toe" << endl;
        cin >> GameNum;
        if (GameNum == 1)
            break;
        else
            cout << "sorry we do not support anthor game yet please choose again" << endl;
    }
    cout << "--------------------------------------------" << endl;
    while (1)
    {
        cout << "please enter your name:" << endl;
        cin >> nameP;
        if (nameP.c_str() == nullptr)
            cout << "please enter a valid name! " << endl;
        else
            break;
    }
    cout << "--------------------------------------------" << endl;
    while (1)
    {
        cout << "please choose dificulty : " << endl;
        cout << "1- Easy " << endl;
        cout << "2- Hard " << endl;
        cin >> GameDif;

        switch (GameDif)
        {
        case 1:
        {
            GameController game(new xo_RAN("tic tac toe", nameP, 0, "tic tac toe_AI", "Easy"), new console_board);
            game.play();
            return 0;
        }
        case 2:
        {
            GameController game(new xo_EDU("tic tac toe", nameP, 0, "tic tac toe_AI", "Hard"), new console_board);
            game.play();
            return 0;
        }

        default:
            cout << "--------------------------------------------" << endl;
            cout << "please put a valid dificulty" << endl;
            cout << "--------------------------------------------" << endl;
            break;
        }
    }
    return 0;
}
